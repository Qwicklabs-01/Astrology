import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import VedicForecast from './components/VedicForecast.jsx'

// Render the main App to the #root element for dev and full-page mode
const rootElement = document.getElementById('root')
if (rootElement) {
  createRoot(rootElement).render(
    <StrictMode>
      <App />
    </StrictMode>,
  )
}

// Optionally, keep the forecast-root mount for WordPress theme integration
const forecastElement = document.getElementById('forecast-root')
if (forecastElement) {
  createRoot(forecastElement).render(
    <StrictMode>
      <VedicForecast />
    </StrictMode>,
  )
}
