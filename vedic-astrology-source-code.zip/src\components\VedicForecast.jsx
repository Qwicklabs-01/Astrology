import { useState } from "react";
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, Area, AreaChart, ReferenceLine
} from "recharts";

const COLORS = {
  gold: "#D4A843",
  goldLight: "#F0C96A",
  goldDim: "#8A6A20",
  cream: "#F5EDD6",
  creamDim: "#C8BA9A",
  bg: "#0A0806",
  bgCard: "#110F0A",
  bgCardBorder: "#2A2218",
  accent: "#C17B2A",
  accentBlue: "#4A8FA3",
  accentRed: "#A34A4A",
  accentGreen: "#4A8A5A",
  text: "#E8D9BA",
  textDim: "#8A7A5A",
};

const yearData = [
  {
    year: "2026–27",
    label: "Year 1",
    career: 95,
    finance: 95,
    health: 75,
    relationships: 80,
    overall: 90,
    dasha: "Jupiter / Moon",
    theme: "PEAK EXPANSION",
    color: "#D4A843",
    transit: "Jupiter in Cancer (10th house)",
    highlight: "Strongest career & income window. Major promotion or business breakthrough expected Sep 2026–Jan 2027.",
    icon: "☿",
  },
  {
    year: "2027–28",
    label: "Year 2",
    career: 65,
    finance: 60,
    health: 70,
    relationships: 55,
    overall: 62,
    dasha: "Jupiter / Mars → Saturn MD",
    theme: "PIVOT & TRANSITION",
    color: "#C17B2A",
    transit: "Saturn approaching Aries (7th house)",
    highlight: "Mahadasha transition. Career identity shifts. A defining professional choice between security and ambition.",
    icon: "♂",
  },
  {
    year: "2028–29",
    label: "Year 3",
    career: 50,
    finance: 45,
    health: 55,
    relationships: 50,
    overall: 48,
    dasha: "Saturn / Saturn",
    theme: "KARMIC FOUNDATION",
    color: "#7A6030",
    transit: "Saturn in Aries (7th house)",
    highlight: "Most demanding year. Hard work with slow visible results. What you build now defines the next decade.",
    icon: "♄",
  },
  {
    year: "2029–30",
    label: "Year 4",
    career: 68,
    finance: 65,
    health: 65,
    relationships: 60,
    overall: 65,
    dasha: "Saturn / Saturn (closing)",
    theme: "CREDIBILITY EMERGES",
    color: "#8A8050",
    transit: "Saturn entering Taurus",
    highlight: "Professional credibility solidifies. Peer recognition arrives. Strong window for long-term asset acquisition.",
    icon: "⊕",
  },
  {
    year: "2030–31",
    label: "Year 5",
    career: 82,
    finance: 80,
    health: 78,
    relationships: 75,
    overall: 80,
    dasha: "Saturn / Mercury",
    theme: "SECOND ASCENT",
    color: "#D4A843",
    transit: "Saturn conjunct natal Jupiter/Rahu",
    highlight: "Renewal. Multiple income streams, intellectual authority, business ventures. Second peak of the 5-year window.",
    icon: "☿",
  },
];

const planetData = [
  { planet: "☉ Sun", sign: "Aries", nakshatra: "Bharani", house: "7th", strength: 78, role: "Partnerships & Identity" },
  { planet: "☽ Moon", sign: "Libra", nakshatra: "Swati", house: "1st (Lagna)", strength: 72, role: "Career & Mind" },
  { planet: "♄ Saturn", sign: "Taurus", nakshatra: "Krittika", house: "8th", strength: 65, role: "Transformation & Karma" },
  { planet: "♃ Jupiter", sign: "Taurus", nakshatra: "Rohini", house: "8th", strength: 82, role: "Wealth & Wisdom" },
  { planet: "☊ Rahu", sign: "Taurus", nakshatra: "Rohini", house: "8th", strength: 58, role: "Ambition & Disruption" },
  { planet: "☋ Ketu", sign: "Scorpio", nakshatra: "Anuradha", house: "2nd", strength: 55, role: "Spiritual Depth" },
];

const dashaTimeline = [
  { name: "Rahu MD", start: 2001, end: 2012, color: "#6A4A8A" },
  { name: "Jupiter MD", start: 2012, end: 2028, color: "#D4A843" },
  { name: "Saturn MD", start: 2028, end: 2047, color: "#5A7A8A" },
  { name: "Mercury MD", start: 2047, end: 2064, color: "#4A8A5A" },
];

const antardasha = [
  { label: "Jup/Venus", period: "mid-2022 → mid-2025", status: "past" },
  { label: "Jup/Sun", period: "mid-2025 → Mar 2026", status: "past" },
  { label: "Jup/Moon", period: "Mar 2026 → Jun 2027", status: "current" },
  { label: "Jup/Mars", period: "Jun 2027 → May 2028", status: "near" },
  { label: "Sat/Sat", period: "late 2028 → 2031", status: "future" },
  { label: "Sat/Mercury", period: "2031 → 2033", status: "future" },
];

const radarData = yearData.map(y => ({
  year: y.label,
  Career: y.career,
  Finance: y.finance,
  Health: y.health,
  Relations: y.relationships,
}));

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div style={{
        background: "#110F0A",
        border: "1px solid #2A2218",
        borderLeft: "3px solid #D4A843",
        padding: "12px 16px",
        borderRadius: "4px",
        fontFamily: "'Georgia', serif",
      }}>
        <p style={{ color: "#D4A843", margin: "0 0 8px", fontSize: "13px", fontWeight: "bold" }}>{label}</p>
        {payload.map((p, i) => (
          <p key={i} style={{ color: p.color, margin: "3px 0", fontSize: "12px" }}>
            {p.name}: <strong>{p.value}</strong>
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function VedicForecast() {
  const [activeYear, setActiveYear] = useState(0);
  const [activeTab, setActiveTab] = useState("overview");
  const selected = yearData[activeYear];

  return (
    <div style={{
      background: COLORS.bg,
      minHeight: "100vh",
      fontFamily: "'Georgia', serif",
      color: COLORS.text,
      padding: "0",
      position: "relative",
      overflow: "hidden",
    }}>
      {/* Starfield background */}
      <div style={{
        position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
        background: "radial-gradient(ellipse at 20% 20%, rgba(212,168,67,0.05) 0%, transparent 60%), radial-gradient(ellipse at 80% 80%, rgba(74,143,163,0.04) 0%, transparent 60%)",
        pointerEvents: "none", zIndex: 0,
      }} />

      <div style={{ position: "relative", zIndex: 1, maxWidth: "1100px", margin: "0 auto", padding: "32px 20px" }}>

        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: "40px" }}>
          <div style={{ fontSize: "11px", letterSpacing: "6px", color: COLORS.goldDim, marginBottom: "10px", textTransform: "uppercase" }}>
            Vimshottari Dasha · Chandra Lagna Analysis
          </div>
          <h1 style={{
            fontSize: "clamp(26px, 5vw, 42px)", margin: "0 0 8px",
            background: `linear-gradient(135deg, ${COLORS.goldLight}, ${COLORS.gold}, ${COLORS.accent})`,
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            letterSpacing: "2px",
          }}>
            VEDIC 5-YEAR FORECAST
          </h1>
          <div style={{ color: COLORS.creamDim, fontSize: "13px", letterSpacing: "3px" }}>
            9 MAY 2001 · KOLKATA · 2026 – 2031
          </div>
          <div style={{
            display: "inline-block", marginTop: "16px",
            padding: "6px 20px", border: "1px solid #D4A843",
            fontSize: "12px", color: COLORS.goldLight, letterSpacing: "2px",
            borderRadius: "2px",
          }}>
            ✦ CURRENTLY: JUPITER / MOON ANTARDASHA ✦
          </div>
        </div>

        {/* Natal Signature Banner */}
        <div style={{
          background: "linear-gradient(135deg, rgba(212,168,67,0.08), rgba(193,123,42,0.04))",
          border: "1px solid rgba(212,168,67,0.25)",
          borderRadius: "8px", padding: "16px 24px", marginBottom: "32px",
          display: "flex", flexWrap: "wrap", gap: "12px", alignItems: "center",
        }}>
          <span style={{ color: COLORS.gold, fontSize: "14px", fontWeight: "bold", letterSpacing: "1px" }}>⚡ NATAL SIGNATURE:</span>
          <span style={{ color: COLORS.creamDim, fontSize: "13px", lineHeight: "1.6" }}>
            Rare <strong style={{ color: COLORS.cream }}>Saturn + Jupiter + Rahu triple conjunction</strong> in Taurus (Rohini Nakshatra) · 8th house from Moon ·
            Sun opposite Moon (Full Moon birth) · Moon in Swati (Rahu-ruled) · Chandra Lagna: <strong style={{ color: COLORS.cream }}>Libra</strong>
          </span>
        </div>

        {/* Nav Tabs */}
        <div style={{ display: "flex", gap: "8px", marginBottom: "28px", flexWrap: "wrap" }}>
          {[
            { key: "overview", label: "📊 5-Year Overview" },
            { key: "dasha", label: "⏳ Dasha Timeline" },
            { key: "planets", label: "🪐 Planetary Chart" },
            { key: "radar", label: "🎯 Life Radar" },
          ].map(tab => (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)} style={{
              background: activeTab === tab.key ? "rgba(212,168,67,0.15)" : "transparent",
              border: activeTab === tab.key ? "1px solid #D4A843" : "1px solid #2A2218",
              color: activeTab === tab.key ? COLORS.goldLight : COLORS.textDim,
              padding: "8px 18px", borderRadius: "4px", cursor: "pointer",
              fontSize: "13px", letterSpacing: "0.5px", transition: "all 0.2s",
              fontFamily: "'Georgia', serif",
            }}>
              {tab.label}
            </button>
          ))}
        </div>

        {/* OVERVIEW TAB */}
        {activeTab === "overview" && (
          <div>
            {/* Year Selector */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(100px, 1fr))", gap: "8px", marginBottom: "24px" }}>
              {yearData.map((y, i) => (
                <button key={i} onClick={() => setActiveYear(i)} style={{
                  background: activeYear === i ? `rgba(212,168,67,0.12)` : "rgba(17,15,10,0.8)",
                  border: activeYear === i ? `1px solid ${y.color}` : "1px solid #2A2218",
                  borderRadius: "6px", padding: "12px 8px", cursor: "pointer",
                  textAlign: "center", transition: "all 0.2s", fontFamily: "'Georgia', serif",
                }}>
                  <div style={{ fontSize: "18px", marginBottom: "4px" }}>{y.icon}</div>
                  <div style={{ color: activeYear === i ? y.color : COLORS.textDim, fontSize: "11px", fontWeight: "bold", letterSpacing: "1px" }}>
                    {y.label}
                  </div>
                  <div style={{ color: activeYear === i ? COLORS.creamDim : "#4A3A2A", fontSize: "10px", marginTop: "2px" }}>
                    {y.year}
                  </div>
                  <div style={{
                    marginTop: "8px", height: "3px", borderRadius: "2px",
                    background: activeYear === i ? y.color : "#2A2218",
                    width: `${y.overall}%`,
                  }} />
                </button>
              ))}
            </div>

            {/* Selected Year Detail */}
            <div style={{
              background: "rgba(17,15,10,0.9)", border: `1px solid ${selected.color}`,
              borderRadius: "8px", padding: "24px", marginBottom: "24px",
              borderLeft: `4px solid ${selected.color}`,
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: "12px", marginBottom: "16px" }}>
                <div>
                  <span style={{ color: selected.color, fontSize: "11px", letterSpacing: "4px", textTransform: "uppercase" }}>
                    {selected.year} · {selected.label}
                  </span>
                  <h2 style={{ margin: "4px 0 0", color: COLORS.cream, fontSize: "22px", letterSpacing: "2px" }}>
                    {selected.theme}
                  </h2>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ color: COLORS.textDim, fontSize: "11px", letterSpacing: "2px" }}>DASHA</div>
                  <div style={{ color: selected.color, fontSize: "13px", fontWeight: "bold" }}>{selected.dasha}</div>
                  <div style={{ color: COLORS.textDim, fontSize: "11px", marginTop: "4px" }}>{selected.transit}</div>
                </div>
              </div>
              <p style={{ color: COLORS.creamDim, fontSize: "13px", lineHeight: "1.8", margin: "0 0 20px" }}>
                {selected.highlight}
              </p>
              {/* Score bars */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: "12px" }}>
                {[
                  { label: "Career", value: selected.career, color: COLORS.gold },
                  { label: "Finance", value: selected.finance, color: COLORS.accentBlue },
                  { label: "Health", value: selected.health, color: COLORS.accentGreen },
                  { label: "Relationships", value: selected.relationships, color: COLORS.accent },
                ].map(s => (
                  <div key={s.label}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                      <span style={{ color: COLORS.textDim, fontSize: "11px", letterSpacing: "1px" }}>{s.label}</span>
                      <span style={{ color: s.color, fontSize: "12px", fontWeight: "bold" }}>{s.value}/100</span>
                    </div>
                    <div style={{ height: "6px", background: "#1A1810", borderRadius: "3px", overflow: "hidden" }}>
                      <div style={{
                        height: "100%", width: `${s.value}%`,
                        background: `linear-gradient(90deg, ${s.color}88, ${s.color})`,
                        borderRadius: "3px", transition: "width 0.6s ease",
                      }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Main Area Chart */}
            <div style={{
              background: "rgba(17,15,10,0.8)", border: "1px solid #2A2218",
              borderRadius: "8px", padding: "24px",
            }}>
              <div style={{ color: COLORS.textDim, fontSize: "11px", letterSpacing: "3px", marginBottom: "16px" }}>
                CAREER & FINANCE TRAJECTORY
              </div>
              <ResponsiveContainer width="100%" height={260}>
                <AreaChart data={yearData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="careerGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#D4A843" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#D4A843" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="financeGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#4A8FA3" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#4A8FA3" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1E1A12" />
                  <XAxis dataKey="year" tick={{ fill: COLORS.textDim, fontSize: 11 }} axisLine={{ stroke: "#2A2218" }} tickLine={false} />
                  <YAxis tick={{ fill: COLORS.textDim, fontSize: 10 }} axisLine={false} tickLine={false} domain={[0, 100]} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend wrapperStyle={{ color: COLORS.textDim, fontSize: "12px" }} />
                  <ReferenceLine y={70} stroke="#2A2218" strokeDasharray="4 4" label={{ value: "Favorable", fill: COLORS.textDim, fontSize: 10 }} />
                  <Area type="monotone" dataKey="career" name="Career" stroke={COLORS.gold} fill="url(#careerGrad)" strokeWidth={2} dot={{ fill: COLORS.gold, r: 4 }} />
                  <Area type="monotone" dataKey="finance" name="Finance" stroke={COLORS.accentBlue} fill="url(#financeGrad)" strokeWidth={2} dot={{ fill: COLORS.accentBlue, r: 4 }} />
                  <Area type="monotone" dataKey="overall" name="Overall" stroke="#8A6A20" fill="none" strokeWidth={1} strokeDasharray="4 4" dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* DASHA TIMELINE TAB */}
        {activeTab === "dasha" && (
          <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
            {/* Mahadasha bar */}
            <div style={{
              background: "rgba(17,15,10,0.8)", border: "1px solid #2A2218",
              borderRadius: "8px", padding: "24px",
            }}>
              <div style={{ color: COLORS.textDim, fontSize: "11px", letterSpacing: "3px", marginBottom: "20px" }}>
                MAHADASHA LIFECYCLE (BIRTH → AGE 63)
              </div>
              <div style={{ position: "relative", height: "60px", background: "#0D0B07", borderRadius: "4px", overflow: "hidden" }}>
                {dashaTimeline.map((d, i) => {
                  const total = 2064 - 2001;
                  const left = ((d.start - 2001) / total) * 100;
                  const width = ((d.end - d.start) / total) * 100;
                  const isCurrent = d.name === "Jupiter MD";
                  const isNext = d.name === "Saturn MD";
                  return (
                    <div key={i} style={{
                      position: "absolute", top: 0, bottom: 0,
                      left: `${left}%`, width: `${width}%`,
                      background: isCurrent ? `${d.color}33` : isNext ? `${d.color}22` : `${d.color}18`,
                      borderRight: "1px solid #0A0806",
                      borderLeft: isCurrent ? `3px solid ${d.color}` : isNext ? `2px solid ${d.color}88` : "none",
                      display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                    }}>
                      <div style={{ fontSize: "10px", color: isCurrent ? d.color : isNext ? `${d.color}AA` : "#4A3A2A", letterSpacing: "0.5px", textAlign: "center", padding: "0 4px" }}>
                        {isCurrent ? "▶ " : ""}{d.name}
                      </div>
                      <div style={{ fontSize: "9px", color: "#3A3020", marginTop: "2px" }}>{d.start}–{d.end}</div>
                    </div>
                  );
                })}
                {/* NOW marker */}
                <div style={{
                  position: "absolute", top: 0, bottom: 0, left: `${((2026 - 2001) / (2064 - 2001)) * 100}%`,
                  width: "2px", background: "#D4A843", opacity: 0.8,
                }}>
                  <div style={{ position: "absolute", top: "-18px", left: "-12px", color: "#D4A843", fontSize: "9px", letterSpacing: "1px" }}>NOW</div>
                </div>
              </div>
              <div style={{ display: "flex", gap: "16px", marginTop: "16px", flexWrap: "wrap" }}>
                {dashaTimeline.map((d, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <div style={{ width: "10px", height: "10px", background: d.color, borderRadius: "2px" }} />
                    <span style={{ fontSize: "11px", color: COLORS.textDim }}>{d.name} ({d.end - d.start} yrs)</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Antardasha sequence */}
            <div style={{
              background: "rgba(17,15,10,0.8)", border: "1px solid #2A2218",
              borderRadius: "8px", padding: "24px",
            }}>
              <div style={{ color: COLORS.textDim, fontSize: "11px", letterSpacing: "3px", marginBottom: "20px" }}>
                ANTARDASHA (SUB-PERIOD) SEQUENCE
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                {antardasha.map((a, i) => (
                  <div key={i} style={{
                    display: "flex", alignItems: "center", gap: "16px",
                    padding: "12px 16px", borderRadius: "6px",
                    background: a.status === "current" ? "rgba(212,168,67,0.1)" : "rgba(17,15,10,0.5)",
                    border: a.status === "current" ? "1px solid #D4A843" : "1px solid #1A1810",
                  }}>
                    <div style={{
                      width: "8px", height: "8px", borderRadius: "50%",
                      background: a.status === "current" ? COLORS.gold : a.status === "past" ? "#3A3020" : a.status === "near" ? "#8A6020" : "#2A2218",
                      flexShrink: 0,
                    }} />
                    <div style={{ flex: 1 }}>
                      <span style={{
                        color: a.status === "current" ? COLORS.goldLight : a.status === "past" ? COLORS.textDim : COLORS.creamDim,
                        fontSize: "13px", fontWeight: a.status === "current" ? "bold" : "normal",
                      }}>
                        {a.label}
                      </span>
                      {a.status === "current" && (
                        <span style={{ marginLeft: "10px", fontSize: "10px", color: COLORS.gold, letterSpacing: "2px" }}>← YOU ARE HERE</span>
                      )}
                    </div>
                    <div style={{ color: COLORS.textDim, fontSize: "11px" }}>{a.period}</div>
                    <div style={{
                      fontSize: "10px", letterSpacing: "1px",
                      color: a.status === "current" ? COLORS.gold : a.status === "past" ? "#3A3020" : a.status === "near" ? "#8A6020" : "#2A2218",
                    }}>
                      {a.status === "current" ? "ACTIVE" : a.status === "past" ? "PAST" : a.status === "near" ? "NEXT" : "FUTURE"}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Overall scores bar chart */}
            <div style={{
              background: "rgba(17,15,10,0.8)", border: "1px solid #2A2218",
              borderRadius: "8px", padding: "24px",
            }}>
              <div style={{ color: COLORS.textDim, fontSize: "11px", letterSpacing: "3px", marginBottom: "16px" }}>
                YEAR-BY-YEAR COMPARATIVE SCORES
              </div>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={yearData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1E1A12" vertical={false} />
                  <XAxis dataKey="year" tick={{ fill: COLORS.textDim, fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: COLORS.textDim, fontSize: 10 }} axisLine={false} tickLine={false} domain={[0, 100]} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend wrapperStyle={{ color: COLORS.textDim, fontSize: "12px" }} />
                  <Bar dataKey="career" name="Career" fill={COLORS.gold} opacity={0.85} radius={[3, 3, 0, 0]} />
                  <Bar dataKey="finance" name="Finance" fill={COLORS.accentBlue} opacity={0.85} radius={[3, 3, 0, 0]} />
                  <Bar dataKey="health" name="Health" fill={COLORS.accentGreen} opacity={0.85} radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* PLANETS TAB */}
        {activeTab === "planets" && (
          <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
            {/* House wheel simplified */}
            <div style={{
              background: "rgba(17,15,10,0.8)", border: "1px solid #2A2218",
              borderRadius: "8px", padding: "24px",
            }}>
              <div style={{ color: COLORS.textDim, fontSize: "11px", letterSpacing: "3px", marginBottom: "20px" }}>
                CHANDRA LAGNA HOUSE MAP (LIBRA ASCENDANT)
              </div>
              <div style={{ overflowX: "auto", paddingBottom: "8px" }}>
                <div style={{
                  display: "grid", gridTemplateColumns: "repeat(4, minmax(80px, 1fr))",
                  gridTemplateRows: "repeat(3, auto)", gap: "2px", minWidth: "400px"
                }}>
                {[
                  { h: "12", sign: "Virgo", planets: "", note: "Losses · Foreign" },
                  { h: "1", sign: "Libra", planets: "☽ Moon", note: "Self · LAGNA", highlight: true },
                  { h: "2", sign: "Scorpio", planets: "☋ Ketu", note: "Wealth · Speech" },
                  { h: "3", sign: "Sagittarius", planets: "", note: "Courage · Comms" },
                  { h: "11", sign: "Leo", planets: "", note: "Gains · Income" },
                  { h: "CENTER", sign: "", planets: "Born\n9 May 2001\nKolkata", note: "", center: true },
                  { h: "CENTER2", sign: "", planets: "", note: "", center: true, empty: true },
                  { h: "4", sign: "Capricorn", planets: "", note: "Home · Mother" },
                  { h: "10", sign: "Cancer", planets: "", note: "Career · Fame" },
                  { h: "CENTER3", sign: "", planets: "", note: "", center: true, empty: true },
                  { h: "CENTER4", sign: "", planets: "", note: "", center: true, empty: true },
                  { h: "5", sign: "Aquarius", planets: "", note: "Intelligence" },
                  { h: "9", sign: "Gemini", planets: "", note: "Fortune · Dharma" },
                  { h: "8", sign: "Taurus", planets: "♄♃☊", note: "Transformation ★", power: true },
                  { h: "7", sign: "Aries", planets: "☉ Sun", note: "Partnerships" },
                  { h: "6", sign: "Pisces", planets: "", note: "Health · Enemies" },
                ].map((cell, i) => {
                  if (cell.center) return (
                    <div key={i} style={{
                      background: "#0D0B07",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      minHeight: "80px", borderRadius: "2px",
                    }}>
                      {!cell.empty && (
                        <div style={{ textAlign: "center", color: COLORS.textDim, fontSize: "11px", lineHeight: "1.6", whiteSpace: "pre-line" }}>
                          {cell.planets}
                        </div>
                      )}
                    </div>
                  );
                  return (
                    <div key={i} style={{
                      background: cell.highlight ? "rgba(212,168,67,0.08)" : cell.power ? "rgba(193,123,42,0.12)" : "rgba(17,15,10,0.6)",
                      border: cell.highlight ? "1px solid rgba(212,168,67,0.4)" : cell.power ? "1px solid rgba(193,123,42,0.4)" : "1px solid #1A1810",
                      borderRadius: "4px", padding: "10px 8px", minHeight: "80px",
                    }}>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                        <span style={{ color: COLORS.textDim, fontSize: "9px", letterSpacing: "1px" }}>H{cell.h}</span>
                        <span style={{ color: cell.highlight ? COLORS.gold : cell.power ? COLORS.accent : COLORS.textDim, fontSize: "9px" }}>{cell.sign}</span>
                      </div>
                      {cell.planets && (
                        <div style={{ color: cell.highlight ? COLORS.goldLight : cell.power ? "#FFB86C" : COLORS.cream, fontSize: "16px", marginBottom: "4px", letterSpacing: "2px" }}>
                          {cell.planets}
                        </div>
                      )}
                      <div style={{ color: "#4A3A2A", fontSize: "9px", lineHeight: "1.4" }}>{cell.note}</div>
                    </div>
                  );
                })}
              </div>
              </div>
              <div style={{ marginTop: "12px", color: COLORS.textDim, fontSize: "11px" }}>
                ★ <strong style={{ color: COLORS.accent }}>8th house triple conjunction</strong> (Saturn + Jupiter + Rahu) is the dominant natal signature — rules hidden wealth, transformation, and karmic depth.
              </div>
            </div>

            {/* Planetary strength chart */}
            <div style={{
              background: "rgba(17,15,10,0.8)", border: "1px solid #2A2218",
              borderRadius: "8px", padding: "24px",
            }}>
              <div style={{ color: COLORS.textDim, fontSize: "11px", letterSpacing: "3px", marginBottom: "16px" }}>
                PLANETARY STRENGTH & ROLE
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                {planetData.map((p, i) => (
                  <div key={i} style={{ display: "flex", flexWrap: "wrap", gap: "12px", alignItems: "center", borderBottom: "1px solid #1A1810", paddingBottom: "8px" }}>
                    <div style={{ flex: "1 1 100px", color: COLORS.cream, fontSize: "13px" }}>{p.planet}</div>
                    <div style={{ flex: "1 1 60px", color: COLORS.textDim, fontSize: "11px" }}>{p.sign}</div>
                    <div style={{ flex: "1 1 80px", color: COLORS.textDim, fontSize: "10px" }}>{p.nakshatra}</div>
                    <div style={{ flex: "1 1 150px" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "3px" }}>
                        <span style={{ color: "#4A4030", fontSize: "10px" }}>{p.role}</span>
                        <span style={{ color: COLORS.gold, fontSize: "10px" }}>{p.strength}%</span>
                      </div>
                      <div style={{ height: "4px", background: "#1A1810", borderRadius: "2px" }}>
                        <div style={{
                          height: "100%", width: `${p.strength}%`,
                          background: `linear-gradient(90deg, ${COLORS.accent}88, ${COLORS.gold})`,
                          borderRadius: "2px",
                        }} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* RADAR TAB */}
        {activeTab === "radar" && (
          <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
            <div style={{
              background: "rgba(17,15,10,0.8)", border: "1px solid #2A2218",
              borderRadius: "8px", padding: "24px",
            }}>
              <div style={{ color: COLORS.textDim, fontSize: "11px", letterSpacing: "3px", marginBottom: "16px" }}>
                LIFE AREA RADAR — ALL 5 YEARS
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: "16px" }}>
                {yearData.map((y, i) => (
                  <div key={i} style={{
                    background: "#0D0B07", border: `1px solid ${y.color}44`,
                    borderRadius: "6px", padding: "16px",
                  }}>
                    <div style={{ color: y.color, fontSize: "11px", letterSpacing: "2px", marginBottom: "8px" }}>
                      {y.label}: {y.year}
                    </div>
                    <div style={{ color: COLORS.textDim, fontSize: "10px", marginBottom: "12px" }}>{y.theme}</div>
                    <ResponsiveContainer width="100%" height={180}>
                      <RadarChart data={[
                        { subject: "Career", value: y.career },
                        { subject: "Finance", value: y.finance },
                        { subject: "Health", value: y.health },
                        { subject: "Relations", value: y.relationships },
                        { subject: "Overall", value: y.overall },
                      ]}>
                        <PolarGrid stroke="#1E1A12" />
                        <PolarAngleAxis dataKey="subject" tick={{ fill: COLORS.textDim, fontSize: 9 }} />
                        <PolarRadiusAxis angle={90} domain={[0, 100]} tick={false} axisLine={false} />
                        <Radar name={y.label} dataKey="value" stroke={y.color} fill={y.color} fillOpacity={0.2} strokeWidth={2} />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>
                ))}
              </div>
            </div>

            {/* Gemstone & Remedy */}
            <div style={{
              background: "rgba(17,15,10,0.8)", border: "1px solid #2A2218",
              borderRadius: "8px", padding: "24px",
            }}>
              <div style={{ color: COLORS.textDim, fontSize: "11px", letterSpacing: "3px", marginBottom: "20px" }}>
                GEMSTONES & REMEDIES
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "12px" }}>
                {[
                  { gem: "Yellow Sapphire", planet: "♃ Jupiter", color: "#D4A843", day: "Thursday", metal: "Gold", finger: "Right Index", carat: "5+ carats", urgency: "WEAR NOW" },
                  { gem: "Pearl", planet: "☽ Moon", color: "#C8D8E8", day: "Monday", metal: "Silver", finger: "Right Small", carat: "5–7 carats", urgency: "RECOMMENDED" },
                  { gem: "White Sapphire", planet: "♀ Venus", color: "#E8E8F0", day: "Friday", metal: "Platinum", finger: "Right Ring", carat: "4+ carats", urgency: "OPTIONAL" },
                ].map((g, i) => (
                  <div key={i} style={{
                    background: "#0D0B07", border: `1px solid ${g.color}44`,
                    borderRadius: "6px", padding: "16px", textAlign: "center",
                  }}>
                    <div style={{ fontSize: "28px", marginBottom: "8px" }}>💎</div>
                    <div style={{ color: g.color, fontSize: "13px", fontWeight: "bold", marginBottom: "4px" }}>{g.gem}</div>
                    <div style={{ color: COLORS.textDim, fontSize: "11px", marginBottom: "12px" }}>{g.planet}</div>
                    <div style={{
                      display: "inline-block", padding: "2px 10px",
                      border: `1px solid ${g.color}66`, borderRadius: "2px",
                      color: g.color, fontSize: "9px", letterSpacing: "2px", marginBottom: "12px",
                    }}>{g.urgency}</div>
                    <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
                      {[
                        ["Day", g.day], ["Metal", g.metal], ["Finger", g.finger], ["Min.", g.carat]
                      ].map(([k, v]) => (
                        <div key={k} style={{ display: "flex", justifyContent: "space-between" }}>
                          <span style={{ color: "#4A3A2A", fontSize: "10px" }}>{k}</span>
                          <span style={{ color: COLORS.creamDim, fontSize: "10px" }}>{v}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div style={{
          textAlign: "center", marginTop: "40px", paddingTop: "24px",
          borderTop: "1px solid #1A1810",
          color: COLORS.textDim, fontSize: "11px", lineHeight: "1.8",
        }}>
          <div style={{ color: "#4A3A2A", letterSpacing: "1px" }}>
            ⚠️ Analysis based on Chandra Lagna (Moon as Ascendant) due to unknown birth time · Accuracy: 65–75%
          </div>
          <div style={{ marginTop: "6px", color: "#3A3020" }}>
            Vimshottari Dasha · Lahiri Ayanamsa · Sidereal positions · All timings carry ±12–18 month margin
          </div>
        </div>

      </div>
    </div>
  );
}
