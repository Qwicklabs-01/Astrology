import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const Panchang = () => {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [location, setLocation] = useState('New Delhi, India');
  const [panchangData, setPanchangData] = useState(null);

  const fetchPanchang = (e) => {
    if (e) e.preventDefault();
    
    // Mock data for the demonstration
    setPanchangData({
      sunrise: "05:42 AM",
      sunset: "06:58 PM",
      moonrise: "08:15 PM",
      moonset: "07:30 AM",
      tithi: { name: "Shukla Paksha Purnima", end: "04:22 PM" },
      nakshatra: { name: "Swati", lord: "Rahu", end: "11:45 PM" },
      yoga: { name: "Siddhi", end: "02:10 PM" },
      karana: { name: "Bava", end: "04:22 PM" },
      vaar: "Somavaara (Monday)",
      auspicious: [
        { name: "Abhijit Muhurta", time: "11:58 AM - 12:50 PM" },
        { name: "Amrit Kalam", time: "06:20 PM - 08:05 PM" }
      ],
      inauspicious: [
        { name: "Rahu Kalam", time: "07:30 AM - 09:00 AM" },
        { name: "Yama Gandam", time: "10:30 AM - 12:00 PM" }
      ]
    });
  };

  // Load initial data
  useEffect(() => {
    fetchPanchang();
  }, []);

  return (
    <div className="pt-24 pb-20 min-h-screen bg-primary relative overflow-hidden">
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-gold/5 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <div className="font-accent text-xs tracking-[0.3em] text-gold/80 mb-4 uppercase">The Five Limbs of Time</div>
          <h1 className="font-hero text-4xl sm:text-5xl md:text-6xl text-transparent bg-clip-text bg-gradient-to-r from-gold-light to-copper mb-6">
            Daily Panchang
          </h1>
          <p className="font-body text-cream/70 max-w-2xl mx-auto italic text-lg">
            Align your actions with the cosmic rhythm. Check the daily astronomical positions to find auspicious windows for success.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Controls */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}
            className="lg:col-span-4"
          >
            <div className="glass-card p-6 sm:p-8 rounded-xl border border-gold/20 sticky top-24">
              <form onSubmit={fetchPanchang} className="space-y-6">
                <div>
                  <label className="block font-accent text-xs tracking-widest text-gold mb-2 uppercase">Date</label>
                  <input 
                    type="date" value={date} onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-primary/50 border border-gold/30 rounded-md px-4 py-3 font-body text-cream focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold/50" style={{ colorScheme: 'dark' }}
                  />
                </div>
                <div>
                  <label className="block font-accent text-xs tracking-widest text-gold mb-2 uppercase">Location</label>
                  <input 
                    type="text" value={location} onChange={(e) => setLocation(e.target.value)}
                    className="w-full bg-primary/50 border border-gold/30 rounded-md px-4 py-3 font-body text-cream focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold/50"
                  />
                </div>
                <button type="submit" className="w-full py-4 bg-gradient-to-r from-gold to-copper text-primary font-accent uppercase tracking-widest text-sm hover:shadow-[0_0_20px_hsl(var(--color-gold)/0.4)] transition-all duration-300 font-bold rounded-md">
                  Update Almanac
                </button>
              </form>
            </div>
          </motion.div>

          {/* Display */}
          <div className="lg:col-span-8 space-y-6">
            {panchangData && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                
                {/* Sun & Moon Times */}
                <div className="glass-card p-6 rounded-xl border border-gold/20 flex flex-wrap gap-8 justify-around bg-secondary/50">
                  <div className="text-center">
                    <div className="text-gold text-3xl mb-2">🌅</div>
                    <div className="font-accent text-[10px] tracking-widest text-gold/60 uppercase mb-1">Sunrise</div>
                    <div className="font-hero text-xl text-cream">{panchangData.sunrise}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-copper text-3xl mb-2">🌇</div>
                    <div className="font-accent text-[10px] tracking-widest text-gold/60 uppercase mb-1">Sunset</div>
                    <div className="font-hero text-xl text-cream">{panchangData.sunset}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-cream/80 text-3xl mb-2">🌝</div>
                    <div className="font-accent text-[10px] tracking-widest text-gold/60 uppercase mb-1">Moonrise</div>
                    <div className="font-hero text-xl text-cream">{panchangData.moonrise}</div>
                  </div>
                  <div className="text-center">
                    <div className="text-cream/40 text-3xl mb-2">🌚</div>
                    <div className="font-accent text-[10px] tracking-widest text-gold/60 uppercase mb-1">Moonset</div>
                    <div className="font-hero text-xl text-cream">{panchangData.moonset}</div>
                  </div>
                </div>

                {/* The 5 Angas (Limbs) */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="glass-card p-6 rounded-xl border border-gold/20 space-y-4">
                    <h3 className="font-hero text-xl text-gold-light border-b border-gold/10 pb-2 mb-4">The 5 Limbs (Angas)</h3>
                    
                    <div className="flex justify-between items-center pb-2 border-b border-white/5">
                      <span className="font-accent text-[10px] tracking-widest text-gold/80 uppercase w-1/4">Vaar (Day)</span>
                      <span className="font-body text-cream text-sm font-bold w-3/4 text-right">{panchangData.vaar}</span>
                    </div>
                    
                    <div className="flex justify-between items-center pb-2 border-b border-white/5">
                      <span className="font-accent text-[10px] tracking-widest text-gold/80 uppercase w-1/4">Tithi (Phase)</span>
                      <div className="text-right">
                        <div className="font-body text-cream text-sm font-bold">{panchangData.tithi.name}</div>
                        <div className="text-[10px] text-cream/40">Ends: {panchangData.tithi.end}</div>
                      </div>
                    </div>

                    <div className="flex justify-between items-center pb-2 border-b border-white/5">
                      <span className="font-accent text-[10px] tracking-widest text-gold/80 uppercase w-1/4">Nakshatra</span>
                      <div className="text-right">
                        <div className="font-body text-cream text-sm font-bold">{panchangData.nakshatra.name} (Ruler: {panchangData.nakshatra.lord})</div>
                        <div className="text-[10px] text-cream/40">Ends: {panchangData.nakshatra.end}</div>
                      </div>
                    </div>

                    <div className="flex justify-between items-center pb-2 border-b border-white/5">
                      <span className="font-accent text-[10px] tracking-widest text-gold/80 uppercase w-1/4">Yoga</span>
                      <div className="text-right">
                        <div className="font-body text-cream text-sm font-bold">{panchangData.yoga.name}</div>
                        <div className="text-[10px] text-cream/40">Ends: {panchangData.yoga.end}</div>
                      </div>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="font-accent text-[10px] tracking-widest text-gold/80 uppercase w-1/4">Karana</span>
                      <div className="text-right">
                        <div className="font-body text-cream text-sm font-bold">{panchangData.karana.name}</div>
                        <div className="text-[10px] text-cream/40">Ends: {panchangData.karana.end}</div>
                      </div>
                    </div>

                  </div>

                  {/* Auspicious / Inauspicious Timings */}
                  <div className="space-y-6">
                    <div className="glass-card p-6 rounded-xl border border-green-500/30 bg-green-500/5">
                      <h3 className="font-accent text-xs tracking-widest text-green-400 uppercase mb-4 flex items-center gap-2">
                        <span className="text-lg">✨</span> Auspicious Timings
                      </h3>
                      <div className="space-y-3">
                        {panchangData.auspicious.map((item, i) => (
                          <div key={i} className="flex justify-between items-center bg-primary/40 px-4 py-2 rounded-md">
                            <span className="font-body text-cream/90 text-sm">{item.name}</span>
                            <span className="font-accent text-xs text-green-300 tracking-wider">{item.time}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="glass-card p-6 rounded-xl border border-red-500/30 bg-red-500/5">
                      <h3 className="font-accent text-xs tracking-widest text-red-400 uppercase mb-4 flex items-center gap-2">
                        <span className="text-lg">⚠️</span> Inauspicious Timings
                      </h3>
                      <div className="space-y-3">
                        {panchangData.inauspicious.map((item, i) => (
                          <div key={i} className="flex justify-between items-center bg-primary/40 px-4 py-2 rounded-md">
                            <span className="font-body text-cream/90 text-sm">{item.name}</span>
                            <span className="font-accent text-xs text-red-300 tracking-wider">{item.time}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

              </motion.div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};

export default Panchang;
