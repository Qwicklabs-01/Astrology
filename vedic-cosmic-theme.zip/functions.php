<?php
/**
 * Vedic Cosmic Theme functions and definitions
 */

if ( ! function_exists( 'vedic_cosmic_setup' ) ) :
    function vedic_cosmic_setup() {
        // Add default posts and comments RSS feed links to head.
        add_theme_support( 'automatic-feed-links' );

        // Let WordPress manage the document title.
        add_theme_support( 'title-tag' );

        // Enable support for Post Thumbnails on posts and pages.
        add_theme_support( 'post-thumbnails' );

        // Register menus
        register_nav_menus( array(
            'menu-1' => esc_html__( 'Primary', 'vedic-cosmic' ),
        ) );

        // HTML5 support
        add_theme_support( 'html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        ) );
    }
endif;
add_action( 'after_setup_theme', 'vedic_cosmic_setup' );

/**
 * Enqueue scripts and styles.
 */
function vedic_cosmic_scripts() {
    // Google Fonts
    wp_enqueue_style( 'vedic-cosmic-fonts', 'https://fonts.googleapis.com/css2?family=Cinzel+Decorative:wght@400;700&family=Cormorant+Garamond:ital,wght@0,400;0,600;1,400&family=EB+Garamond:ital,wght@0,400;0,600;1,400&family=Josefin+Sans:wght@400;600&family=Noto+Serif+Devanagari:wght@400;600&display=swap', array(), null );

    // Tailwind Compiled CSS (from Vite)
    wp_enqueue_style( 'vedic-cosmic-tailwind', get_template_directory_uri() . '/assets/index.css', array(), '1.0.0' );

    // Theme Main CSS
    wp_enqueue_style( 'vedic-cosmic-style', get_stylesheet_uri(), array('vedic-cosmic-tailwind'), '1.0.0' );

    // Enqueue React App (Vedic Forecast Tool) ONLY on the Forecast page template
    if ( is_page_template( 'page-forecast.php' ) ) {
        wp_enqueue_script( 'vedic-cosmic-react-app', get_template_directory_uri() . '/assets/index.js', array(), '1.0.0', true );
    }
}
add_action( 'wp_enqueue_scripts', 'vedic_cosmic_scripts' );

// Add custom body class
function vedic_cosmic_body_classes( $classes ) {
    $classes[] = 'bg-primary text-cream font-body antialiased selection:bg-gold/30 flex flex-col min-h-screen';
    return $classes;
}
add_filter( 'body_class', 'vedic_cosmic_body_classes' );
