<?php
/**
 * The main template file
 */

get_header();
?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex-grow">
    <?php
    if ( have_posts() ) :
        while ( have_posts() ) :
            the_post();
            ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('mb-12 glass-card p-8'); ?>>
                <header class="entry-header mb-6">
                    <?php
                    if ( is_singular() ) :
                        the_title( '<h1 class="entry-title font-hero text-4xl text-[#C9A84C] mb-4">', '</h1>' );
                    else :
                        the_title( '<h2 class="entry-title font-hero text-3xl text-[#C9A84C] mb-4"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark" class="hover:text-[#E8C96A] transition-colors">', '</a></h2>' );
                    endif;
                    ?>
                </header>

                <div class="entry-content font-body text-[#F0E6CA]/80 prose prose-invert prose-p:text-[#F0E6CA]/80 prose-headings:font-hero prose-headings:text-[#C9A84C] prose-a:text-[#C9A84C] max-w-none">
                    <?php
                    the_content();
                    ?>
                </div>
            </article>
            <?php
        endwhile;
        the_posts_navigation();
    else :
        ?>
        <p class="text-[#F0E6CA]/70 font-body">No content found.</p>
        <?php
    endif;
    ?>
</div>

<?php
get_footer();
