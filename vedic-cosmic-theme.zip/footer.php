    </main><!-- #primary -->

    <footer id="colophon" class="site-footer bg-[#0E1118] border-t border-[#C9A84C]/20 pt-16 pb-8 relative overflow-hidden mt-auto">
        <!-- Decorative top border -->
        <div class="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#C9A84C]/50 to-transparent"></div>
        
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
                <!-- Brand Col -->
                <div class="col-span-1 md:col-span-1">
                    <h2 class="font-hero text-2xl text-[#C9A84C] mb-4"><?php bloginfo('name'); ?></h2>
                    <p class="font-body text-[#F0E6CA]/70 mb-6 italic">
                        "Where Ancient Cosmic Science Meets Modern Precision."
                    </p>
                    <p class="font-accent text-xs tracking-widest text-[#C9A84C]/60 uppercase">
                        25+ Years Experience<br />
                        Jyotish Visharad
                    </p>
                </div>

                <!-- Quick Links -->
                <div>
                    <h3 class="font-accent text-sm tracking-[0.2em] text-[#F0E6CA] uppercase mb-6 border-b border-[#C9A84C]/20 pb-2 inline-block">Services</h3>
                    <ul class="space-y-3 font-body text-[#F0E6CA]/70">
                        <li><a href="#" class="hover:text-[#C9A84C] transition-colors">Vedic Astrology</a></li>
                        <li><a href="#" class="hover:text-[#C9A84C] transition-colors">Vastu Shastra</a></li>
                        <li><a href="#" class="hover:text-[#C9A84C] transition-colors">Numerology</a></li>
                        <li><a href="#" class="hover:text-[#C9A84C] transition-colors">Palmistry</a></li>
                        <li><a href="#" class="hover:text-[#C9A84C] transition-colors">Muhurta Timing</a></li>
                    </ul>
                </div>

                <!-- Tools -->
                <div>
                    <h3 class="font-accent text-sm tracking-[0.2em] text-[#F0E6CA] uppercase mb-6 border-b border-[#C9A84C]/20 pb-2 inline-block">Free Tools</h3>
                    <ul class="space-y-3 font-body text-[#F0E6CA]/70">
                        <li><a href="<?php echo esc_url( home_url( '/forecast' ) ); ?>" class="hover:text-[#C9A84C] transition-colors">5-Year Forecast</a></li>
                        <li><a href="#" class="hover:text-[#C9A84C] transition-colors">Birth Chart Calculator</a></li>
                        <li><a href="#" class="hover:text-[#C9A84C] transition-colors">Panchang Today</a></li>
                        <li><a href="#" class="hover:text-[#C9A84C] transition-colors">Ashtakoot Match</a></li>
                    </ul>
                </div>

                <!-- Newsletter -->
                <div>
                    <h3 class="font-accent text-sm tracking-[0.2em] text-[#F0E6CA] uppercase mb-6 border-b border-[#C9A84C]/20 pb-2 inline-block">Newsletter</h3>
                    <p class="font-body text-[#F0E6CA]/70 mb-4">Receive Cosmic Insights Every New Moon</p>
                    <form class="flex flex-col space-y-3">
                        <input type="email" placeholder="Your email address" class="bg-[#080A0F] border border-[#C9A84C]/30 px-4 py-2 font-body text-[#F0E6CA] focus:outline-none focus:border-[#C9A84C] transition-colors" />
                        <button type="submit" class="bg-[#C9A84C]/10 border border-[#C9A84C] text-[#C9A84C] hover:bg-[#C9A84C] hover:text-[#080A0F] transition-colors font-accent uppercase tracking-widest text-xs py-3">
                            Subscribe
                        </button>
                    </form>
                </div>
            </div>

            <!-- Disclaimer & Copyright -->
            <div class="border-t border-[#C9A84C]/10 pt-8 flex flex-col md:flex-row justify-between items-center text-center md:text-left gap-4">
                <p class="font-body text-xs text-[#F0E6CA]/50 italic">
                    Disclaimer: For guidance purposes only. Not a substitute for professional medical, legal, or financial advice.
                </p>
                <div class="font-accent text-xs tracking-widest text-[#C9A84C]/40 uppercase">
                    &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved.
                </div>
            </div>
        </div>
    </footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
