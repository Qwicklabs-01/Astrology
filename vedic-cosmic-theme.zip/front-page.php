<?php
/**
 * The template for displaying the front page
 */

get_header(); ?>

<div class="flex flex-col w-full">
    <!-- Hero Section -->
    <section class="relative min-h-[90vh] flex items-center overflow-hidden">
        <!-- Starfield Background -->
        <div class="absolute inset-0 z-0 bg-[#080A0F]">
            <div class="absolute inset-0 opacity-30 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#C9A84C]/20 via-[#080A0F] to-[#080A0F]"></div>
            <!-- Subtle stars HTML generated statically for WP -->
            <?php for($i=0; $i<30; $i++): ?>
            <div class="absolute w-1 h-1 bg-white rounded-full star" style="top: <?php echo rand(0, 100); ?>%; left: <?php echo rand(0, 100); ?>%; animation-delay: <?php echo rand(0, 3); ?>s; opacity: <?php echo (rand(1, 5)/10) + 0.1; ?>"></div>
            <?php endfor; ?>
        </div>

        <!-- Hero Content -->
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full flex flex-col md:flex-row items-center justify-between">
            <div class="md:w-1/2 pt-12 md:pt-0 animate-fade-in-up">
                <h1 class="font-hero text-5xl md:text-7xl lg:text-8xl text-transparent bg-clip-text bg-gradient-to-br from-[#E8C96A] via-[#C9A84C] to-[#A0602A] mb-6 leading-tight text-glow">
                    Decode the<br/>Language of<br/>the Cosmos
                </h1>
                <p class="font-sub text-xl md:text-2xl text-[#F0E6CA]/80 mb-8 italic">
                    Vedic Astrology · Vastu Shastra · Numerology · Palmistry · Alchemy
                    <br/>
                    <span class="text-[#C9A84C]/80 not-italic text-lg">Ancient Sciences for Modern Life</span>
                </p>
                <div class="flex flex-col sm:flex-row gap-4 mb-8">
                    <a href="<?php echo esc_url( home_url( '/forecast' ) ); ?>" class="px-8 py-4 bg-gradient-to-r from-[#C9A84C] to-[#A0602A] text-[#080A0F] font-accent uppercase tracking-widest text-sm hover:shadow-[0_0_20px_rgba(201,168,76,0.5)] transition-all text-center font-bold">
                        Explore Forecast Tool
                    </a>
                    <a href="#services" class="px-8 py-4 border border-[#C9A84C] text-[#C9A84C] font-accent uppercase tracking-widest text-sm hover:bg-[#C9A84C]/10 transition-all text-center">
                        Learn the Science
                    </a>
                </div>
                <div class="flex items-center gap-4 text-xs font-accent tracking-widest text-[#F0E6CA]/50 uppercase border-l-2 border-[#C9A84C]/30 pl-4">
                    <p>25+ Years Experience <br/> 10,000+ Charts Analyzed <br/> Jyotish Visharad Certified</p>
                </div>
            </div>

            <!-- Abstract Cosmic Visual -->
            <div class="md:w-1/2 h-[500px] flex items-center justify-center relative mt-12 md:mt-0 opacity-50 md:opacity-100">
                <div class="absolute w-[400px] h-[400px] md:w-[600px] md:h-[600px] border border-[#C9A84C]/10 rounded-full animate-spin-slow"></div>
                <div class="absolute w-[300px] h-[300px] md:w-[450px] md:h-[450px] border border-[#C9A84C]/20 rounded-full flex items-center justify-center animate-[spin_60s_linear_infinite_reverse]">
                    <div class="absolute top-0 text-[#C9A84C] font-sanskrit text-2xl">♈</div>
                    <div class="absolute right-0 text-[#C9A84C] font-sanskrit text-2xl">♋</div>
                    <div class="absolute bottom-0 text-[#C9A84C] font-sanskrit text-2xl">♎</div>
                    <div class="absolute left-0 text-[#C9A84C] font-sanskrit text-2xl">♑</div>
                </div>
                <div class="w-[150px] h-[150px] md:w-[200px] md:h-[200px] bg-gradient-to-tr from-[#C9A84C] to-[#A0602A] rounded-full blur-3xl opacity-30"></div>
                <div class="absolute text-[#E8C96A] text-9xl font-sanskrit opacity-20">ॐ</div>
            </div>
        </div>
    </section>

    <!-- Planetary Ticker -->
    <div class="bg-[#0E1118] border-y border-[#C9A84C]/20 py-3 overflow-hidden">
        <div class="flex whitespace-nowrap animate-marquee text-[#C9A84C] font-sub italic text-lg space-x-12">
            <span>☉ Sun in Aries</span>
            <span>☽ Moon in Libra</span>
            <span>♂ Mars in Capricorn</span>
            <span>☿ Mercury in Pisces</span>
            <span>♃ Jupiter in Taurus</span>
            <span>♀ Venus in Pisces</span>
            <span>♄ Saturn in Aquarius</span>
            <span>☊ Rahu in Pisces</span>
            <span>☋ Ketu in Virgo</span>
            <!-- duplicate for smooth loop -->
            <span>☉ Sun in Aries</span>
            <span>☽ Moon in Libra</span>
        </div>
    </div>

    <!-- Services Overview -->
    <section id="services" class="py-24 bg-[#080A0F] relative">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16">
                <h2 class="font-hero text-4xl md:text-5xl text-[#C9A84C] mb-4">Sacred Sciences</h2>
                <div class="w-24 h-px bg-[#C9A84C]/50 mx-auto"></div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php
                $services = [
                    ["title" => "Vedic Astrology", "desc" => "Deep analysis of your natal chart.", "icon" => "☉"],
                    ["title" => "Vastu Shastra", "desc" => "Align your home with cosmic energies.", "icon" => "🏠"],
                    ["title" => "Numerology", "desc" => "Discover the power of your numbers.", "icon" => "🔢"],
                    ["title" => "Palmistry", "desc" => "Read the map written in your hands.", "icon" => "✋"],
                    ["title" => "Alchemy & Gems", "desc" => "Harness the power of planetary stones.", "icon" => "💎"],
                    ["title" => "Muhurta Timing", "desc" => "Find the perfect moment to start.", "icon" => "⏳"]
                ];
                foreach ($services as $service) :
                ?>
                <div class="glass-card p-8 rounded-sm hover-glow group cursor-pointer">
                    <div class="text-4xl mb-6 opacity-70 group-hover:opacity-100 transition-opacity grayscale group-hover:grayscale-0"><?php echo $service['icon']; ?></div>
                    <h3 class="font-hero text-2xl text-[#F0E6CA] mb-3 group-hover:text-[#C9A84C] transition-colors"><?php echo $service['title']; ?></h3>
                    <p class="font-body text-[#F0E6CA]/60 mb-6 line-clamp-2"><?php echo $service['desc']; ?></p>
                    <div class="font-accent text-xs tracking-[0.2em] text-[#C9A84C] uppercase flex items-center">
                        Explore <span class="ml-2 group-hover:translate-x-2 transition-transform">→</span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Philosophy Strip -->
    <section class="py-20 bg-[#0E1118] relative border-y border-[#C9A84C]/10">
        <div class="absolute inset-0 opacity-5 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCI+PHBhdGggZD0iTTIwIDBsMjAgMjAtMjAgMjBMMCAyMHoiIGZpbGw9IiNDOUE4NEMiLz48L3N2Zz4=')] mix-blend-overlay"></div>
        <div class="max-w-5xl mx-auto px-4 text-center relative z-10">
            <p class="font-sanskrit text-2xl md:text-4xl text-[#C9A84C] mb-6">यथा पिण्डे तथा ब्रह्माण्डे</p>
            <h3 class="font-sub text-2xl md:text-3xl text-[#F0E6CA] mb-8 italic">"Yatha Pinde Tatha Brahmande"</h3>
            <p class="font-body text-lg text-[#F0E6CA]/80 max-w-2xl mx-auto">
                As is the microcosm, so is the macrocosm. The positions of the celestial bodies at your birth are not merely distant rocks in space—they are a mirror reflecting the unique energetic blueprint of your soul's journey.
            </p>
        </div>
    </section>

    <!-- Tools Strip -->
    <section class="py-16 bg-gradient-to-r from-[#C9A84C] to-[#A0602A]">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 class="font-hero text-3xl text-[#080A0F] mb-8">Try Our Free Tools</h2>
            <div class="flex flex-wrap justify-center gap-4">
                <a href="<?php echo esc_url( home_url( '/forecast' ) ); ?>" class="px-6 py-3 bg-[#080A0F] text-[#C9A84C] font-accent uppercase tracking-widest text-sm hover:bg-[#0E1118] transition-colors">
                    5-Year Forecast
                </a>
                <button class="px-6 py-3 bg-[#080A0F] text-[#C9A84C] font-accent uppercase tracking-widest text-sm hover:bg-[#0E1118] transition-colors">
                    Birth Chart Calculator
                </button>
                <button class="px-6 py-3 bg-[#080A0F] text-[#C9A84C] font-accent uppercase tracking-widest text-sm hover:bg-[#0E1118] transition-colors">
                    Vastu Grid Tool
                </button>
            </div>
        </div>
    </section>
</div>

<?php
get_footer();
