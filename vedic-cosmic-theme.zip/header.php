<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">

    <?php wp_head(); ?>
    <style>
      /* Ensure React mounting points take up full width/height when loaded */
      #forecast-root { width: 100%; display: flex; flex-direction: column; flex-grow: 1; }
    </style>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site flex-grow flex flex-col">
    <a class="skip-link screen-reader-text sr-only" href="#primary"><?php esc_html_e( 'Skip to content', 'vedic-cosmic' ); ?></a>

    <header id="masthead" class="site-header">
        <div class="bg-primary text-[#C9A84C] text-center py-2 text-sm font-accent tracking-widest border-b border-[#C9A84C]/10 relative z-50">
            <marquee scrollamount="3">✦ Offering Online & In-Person Consultations · India & Worldwide ✦</marquee>
        </div>
        <nav class="sticky top-0 w-full z-40 transition-all duration-300 bg-[#0E1118]/90 backdrop-blur-md shadow-lg shadow-black/50 py-3">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center">
                    <!-- Logo -->
                    <div class="flex-shrink-0 flex items-center">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="flex flex-col items-center group">
                            <span class="font-hero text-2xl lg:text-3xl text-[#C9A84C] group-hover:text-[#E8C96A] transition-colors">
                                <?php bloginfo( 'name' ); ?>
                            </span>
                            <span class="font-accent text-[10px] tracking-[0.3em] text-[#F0E6CA]/70 uppercase">
                                <?php bloginfo( 'description' ); ?>
                            </span>
                        </a>
                    </div>

                    <!-- Desktop Menu -->
                    <div class="hidden md:flex items-center space-x-8">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="font-accent uppercase text-sm tracking-widest text-[#F0E6CA]/80 hover:text-[#C9A84C] transition-colors relative group">
                            Home
                            <span class="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#C9A84C] transition-all group-hover:w-full"></span>
                        </a>
                        <a href="<?php echo esc_url( home_url( '/#services' ) ); ?>" class="font-accent uppercase text-sm tracking-widest text-[#F0E6CA]/80 hover:text-[#C9A84C] transition-colors relative group">
                            Services
                            <span class="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#C9A84C] transition-all group-hover:w-full"></span>
                        </a>
                        <a href="<?php echo esc_url( home_url( '/forecast' ) ); ?>" class="font-accent uppercase text-sm tracking-widest text-[#F0E6CA]/80 hover:text-[#C9A84C] transition-colors relative group">
                            Forecast Tool
                            <span class="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#C9A84C] transition-all group-hover:w-full"></span>
                        </a>
                        <a href="#consult" class="ml-4 px-6 py-2 border border-[#C9A84C] text-[#C9A84C] font-accent uppercase text-sm tracking-widest hover:bg-[#C9A84C] hover:text-[#080A0F] transition-all duration-300">
                            Book a Reading
                        </a>
                    </div>
                    
                    <!-- Mobile menu button Placeholder -->
                    <div class="md:hidden flex items-center">
                        <button class="text-[#C9A84C] hover:text-[#E8C96A] p-2">
                           Menu
                        </button>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <main id="primary" class="site-main flex-grow flex flex-col">
